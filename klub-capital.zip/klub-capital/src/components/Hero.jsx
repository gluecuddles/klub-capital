import { motion } from "framer-motion";

const Hero = () => (
  <section
    style={{
      minHeight: "100vh",
      display: "flex",
      flexDirection: "column",
      justifyContent: "center",
      alignItems: "center",
      textAlign: "center",
      padding: "120px 40px 80px",
      position: "relative",
      overflow: "hidden",
    }}
  >
    {/* Background grid */}
    <div
      style={{
        position: "absolute",
        inset: 0,
        backgroundImage:
          "linear-gradient(#E4E4E4 1px, transparent 1px), linear-gradient(90deg, #E4E4E4 1px, transparent 1px)",
        backgroundSize: "72px 72px",
        opacity: 0.25,
      }}
    />
    {/* Radial glow */}
    <div
      style={{
        position: "absolute",
        inset: 0,
        background:
          "radial-gradient(ellipse 70% 50% at 50% 40%, rgba(199,169,107,0.07) 0%, transparent 70%)",
      }}
    />

    <div style={{ position: "relative", maxWidth: 760, margin: "0 auto" }}>
      {/* Eyebrow */}
      <motion.div
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.1 }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 12,
            marginBottom: 40,
          }}
        >
          <span
            style={{
              display: "block",
              width: 28,
              height: "1px",
              background: "#C7A96B",
            }}
          />
          <span
            style={{
              fontSize: 11,
              letterSpacing: "0.2em",
              textTransform: "uppercase",
              color: "#C7A96B",
              fontWeight: 400,
            }}
          >
            Invite-only private capital network
          </span>
          <span
            style={{
              display: "block",
              width: 28,
              height: "1px",
              background: "#C7A96B",
            }}
          />
        </div>
      </motion.div>

      {/* Headline */}
      <motion.h1
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.2 }}
        className="serif"
        style={{
          fontSize: "clamp(44px, 7vw, 86px)",
          fontWeight: 300,
          lineHeight: 1.1,
          letterSpacing: "-0.01em",
          color: "#1C1C1C",
          marginBottom: 28,
        }}
      >
        Private capital.
        <br />
        <em style={{ fontStyle: "italic", fontWeight: 300 }}>
          Curated opportunities.
        </em>
      </motion.h1>

      {/* Subtext */}
      <motion.p
        initial={{ opacity: 0, y: 18 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, delay: 0.35 }}
        style={{
          fontSize: 17,
          fontWeight: 300,
          color: "#6B6B6B",
          lineHeight: 1.75,
          maxWidth: 520,
          margin: "0 auto 48px",
        }}
      >
        Klub Capital is an invite-only network connecting serious investors with
        investor-ready businesses.
      </motion.p>

      {/* Buttons */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.5 }}
        style={{
          display: "flex",
          gap: 16,
          justifyContent: "center",
          flexWrap: "wrap",
          marginBottom: 48,
        }}
      >
        <button className="btn-primary">Apply as Investor</button>
        <button className="btn-outline">Submit a Business</button>
      </motion.div>

      {/* Supporting tags */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8, delay: 0.65 }}
        style={{
          display: "flex",
          gap: 32,
          justifyContent: "center",
          flexWrap: "wrap",
        }}
      >
        {["Selective access", "Structured discovery", "Serious capital only"].map(
          (t, i) => (
            <span
              key={i}
              style={{
                fontSize: 11,
                letterSpacing: "0.14em",
                textTransform: "uppercase",
                color: "#ABABAB",
              }}
            >
              {t}
            </span>
          )
        )}
      </motion.div>
    </div>

    {/* Bottom fade */}
    <div
      style={{
        position: "absolute",
        bottom: 0,
        left: 0,
        right: 0,
        height: 80,
        background: "linear-gradient(transparent, #F7F6F3)",
      }}
    />
  </section>
);

export default Hero;
