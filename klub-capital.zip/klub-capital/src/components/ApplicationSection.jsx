import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Reveal from "./Reveal";

const industries = [
  "Consumer",
  "SaaS",
  "Healthcare",
  "Manufacturing",
  "Financial Services",
  "Logistics",
  "Retail",
  "D2C",
  "Other",
];

const FormField = ({ label, type = "text", children, style }) => (
  <div style={{ marginBottom: 28, ...style }}>
    <label
      style={{
        display: "block",
        fontSize: 10,
        letterSpacing: "0.18em",
        textTransform: "uppercase",
        color: "#ABABAB",
        marginBottom: 8,
      }}
    >
      {label}
    </label>
    {children || <input type={type} placeholder="" />}
  </div>
);

const InvestorForm = () => {
  const [industry, setIndustry] = useState("");

  return (
    <div>
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))",
          gap: "0 40px",
        }}
      >
        <FormField label="Full Name" />
        <FormField label="Firm Name" />
        <FormField label="Email" type="email" />
        <FormField label="Investor Type">
          <select>
            <option value="">Select</option>
            {["Angel", "Family Office", "VC", "PE", "HNI", "Institutional"].map(
              (o) => (
                <option key={o}>{o}</option>
              )
            )}
          </select>
        </FormField>
        <FormField label="Preferred Check Size">
          <select>
            <option value="">Select</option>
            {[
              "Under $100K",
              "$100K to $500K",
              "$500K to $1M",
              "$1M to $5M",
              "$5M+",
            ].map((o) => (
              <option key={o}>{o}</option>
            ))}
          </select>
        </FormField>
        <FormField label="Geography" />
        <FormField label="Segments / Industries to Invest In">
          <select onChange={(e) => setIndustry(e.target.value)}>
            <option value="">Select</option>
            {industries.map((o) => (
              <option key={o}>{o}</option>
            ))}
          </select>
        </FormField>
        {industry === "Other" && <FormField label="Other Industry Name" />}
      </div>
      <FormField label="Short Note">
        <textarea
          rows={3}
          placeholder="Tell us briefly about your investment focus and what you are looking for."
        />
      </FormField>
      <button className="btn-primary" style={{ marginTop: 8 }}>
        Apply as Investor
      </button>
    </div>
  );
};

const BusinessForm = () => (
  <div>
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))",
        gap: "0 40px",
      }}
    >
      <FormField label="Founder Name" />
      <FormField label="Company Name" />
      <FormField label="Email" type="email" />
      <FormField label="Industry">
        <select>
          <option value="">Select</option>
          {industries.map((o) => (
            <option key={o}>{o}</option>
          ))}
        </select>
      </FormField>
      <FormField label="Revenue Stage">
        <select>
          <option value="">Select</option>
          {["Pre-Revenue", "Early Revenue", "Growing", "Profitable"].map(
            (o) => (
              <option key={o}>{o}</option>
            )
          )}
        </select>
      </FormField>
      <FormField label="Funding Required">
        <select>
          <option value="">Select</option>
          {[
            "Under $500K",
            "$500K to $1M",
            "$1M to $5M",
            "$5M to $10M",
            "$10M+",
          ].map((o) => (
            <option key={o}>{o}</option>
          ))}
        </select>
      </FormField>
      <FormField label="Business Model" />
      <FormField label="Geography" />
      <FormField label="Website" type="url" />
    </div>
    <FormField label="Short Business Summary">
      <textarea
        rows={3}
        placeholder="Describe your business, traction, and what you are looking for."
      />
    </FormField>
    <button className="btn-primary" style={{ marginTop: 8 }}>
      Submit a Business
    </button>
  </div>
);

const ApplicationSection = () => {
  const [tab, setTab] = useState("investor");

  return (
    <section style={{ background: "#EFEDE7", padding: "100px 40px" }}>
      <div style={{ maxWidth: 1080, margin: "0 auto" }}>
        <Reveal>
          <p
            style={{
              fontSize: 11,
              letterSpacing: "0.2em",
              textTransform: "uppercase",
              color: "#C7A96B",
              marginBottom: 24,
            }}
          >
            Applications
          </p>
          <h2
            className="serif"
            style={{
              fontSize: "clamp(28px, 3.5vw, 46px)",
              fontWeight: 300,
              marginBottom: 56,
              lineHeight: 1.2,
            }}
          >
            Begin your application.
          </h2>
        </Reveal>

        <Reveal delay={0.1}>
          <div
            style={{
              background: "#F7F6F3",
              border: "1px solid #E4E4E4",
              padding: "56px 56px 60px",
            }}
          >
            {/* Tabs */}
            <div
              style={{
                display: "flex",
                gap: 40,
                marginBottom: 52,
                borderBottom: "1px solid #E4E4E4",
              }}
            >
              {[
                ["investor", "Investor"],
                ["business", "Business"],
              ].map(([key, label]) => (
                <button
                  key={key}
                  onClick={() => setTab(key)}
                  style={{
                    background: "none",
                    border: "none",
                    cursor: "pointer",
                    fontSize: 13,
                    letterSpacing: "0.1em",
                    textTransform: "uppercase",
                    padding: "0 0 18px",
                    fontFamily: "'DM Sans', sans-serif",
                    fontWeight: 400,
                    transition: "color 0.2s",
                    color: tab === key ? "#1C1C1C" : "#ABABAB",
                    borderBottom:
                      tab === key
                        ? "1px solid #1C1C1C"
                        : "1px solid transparent",
                    marginBottom: -1,
                  }}
                >
                  {label}
                </button>
              ))}
            </div>

            <AnimatePresence mode="wait">
              <motion.div
                key={tab}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.3 }}
              >
                {tab === "investor" ? <InvestorForm /> : <BusinessForm />}
              </motion.div>
            </AnimatePresence>
          </div>
        </Reveal>
      </div>

      {/* Mobile form padding fix */}
      <style>{`
        @media (max-width: 640px) {
          .form-container { padding: 32px 24px 40px !important; }
        }
      `}</style>
    </section>
  );
};

export default ApplicationSection;
