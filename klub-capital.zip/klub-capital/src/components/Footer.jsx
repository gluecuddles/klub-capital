const Footer = () => (
  <footer
    style={{
      background: "#1C1C1C",
      borderTop: "1px solid rgba(255,255,255,0.06)",
      padding: "56px 40px 40px",
    }}
  >
    <div style={{ maxWidth: 1080, margin: "0 auto" }}>
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-start",
          flexWrap: "wrap",
          gap: 40,
          marginBottom: 56,
        }}
      >
        <div>
          <p
            className="serif"
            style={{
              fontSize: 18,
              fontWeight: 400,
              letterSpacing: "0.12em",
              textTransform: "uppercase",
              color: "#F7F6F3",
              marginBottom: 6,
            }}
          >
            Klub Capital
          </p>
          <p
            style={{
              fontSize: 12,
              letterSpacing: "0.1em",
              textTransform: "uppercase",
              color: "rgba(247,246,243,0.35)",
            }}
          >
            Private capital network
          </p>
        </div>

        <div style={{ display: "flex", gap: 32, flexWrap: "wrap" }}>
          {["About", "Investors", "Businesses", "Privacy", "Contact"].map(
            (l) => (
              <a
                key={l}
                href="#"
                style={{
                  fontSize: 12,
                  letterSpacing: "0.08em",
                  textTransform: "uppercase",
                  color: "rgba(247,246,243,0.4)",
                  textDecoration: "none",
                  transition: "color 0.2s",
                }}
                onMouseEnter={(e) => (e.target.style.color = "#C7A96B")}
                onMouseLeave={(e) =>
                  (e.target.style.color = "rgba(247,246,243,0.4)")
                }
              >
                {l}
              </a>
            )
          )}
        </div>
      </div>

      <hr
        style={{
          border: "none",
          borderTop: "1px solid rgba(255,255,255,0.06)",
          marginBottom: 28,
        }}
      />

      <p
        style={{
          fontSize: 11,
          color: "rgba(247,246,243,0.25)",
          letterSpacing: "0.06em",
        }}
      >
        &copy; {new Date().getFullYear()} Klub Capital. All rights reserved.
      </p>
    </div>
  </footer>
);

export default Footer;
