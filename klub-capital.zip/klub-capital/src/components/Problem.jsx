import Reveal from "./Reveal";

const investors = [
  "Too many irrelevant pitches",
  "Limited visibility beyond existing networks",
  "Poor founder preparation",
  "Time lost filtering weak opportunities",
];

const businesses = [
  "Limited access to serious investors",
  "Fundraising often starts too early",
  "Financials are not always presented clearly",
  "Strong businesses get lost in weak outreach",
];

const Problem = () => (
  <section style={{ background: "#EFEDE7", padding: "100px 40px" }}>
    <div style={{ maxWidth: 1080, margin: "0 auto" }}>
      <Reveal>
        <p
          style={{
            fontSize: 11,
            letterSpacing: "0.2em",
            textTransform: "uppercase",
            color: "#C7A96B",
            marginBottom: 24,
          }}
        >
          The challenge
        </p>
        <h2
          className="serif"
          style={{
            fontSize: "clamp(32px, 4vw, 52px)",
            fontWeight: 300,
            marginBottom: 72,
            lineHeight: 1.2,
          }}
        >
          Where the friction begins
        </h2>
      </Reveal>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
          gap: 64,
        }}
      >
        {[
          { title: "For Investors", items: investors },
          { title: "For Businesses", items: businesses },
        ].map((col, ci) => (
          <Reveal key={ci} delay={ci * 0.15}>
            <p
              style={{
                fontSize: 11,
                letterSpacing: "0.16em",
                textTransform: "uppercase",
                color: "#6B6B6B",
                marginBottom: 32,
              }}
            >
              {col.title}
            </p>
            <div style={{ display: "flex", flexDirection: "column", gap: 0 }}>
              {col.items.map((item, i) => (
                <div
                  key={i}
                  style={{ padding: "18px 0", borderTop: "1px solid #DDD9D0" }}
                >
                  <p
                    style={{
                      fontSize: 15,
                      fontWeight: 300,
                      color: "#1C1C1C",
                      lineHeight: 1.5,
                    }}
                  >
                    {item}
                  </p>
                </div>
              ))}
            </div>
          </Reveal>
        ))}
      </div>

      <Reveal delay={0.3}>
        <hr className="thin-rule" style={{ marginTop: 64, marginBottom: 40 }} />
        <p
          style={{
            fontSize: 15,
            fontWeight: 300,
            color: "#6B6B6B",
            lineHeight: 1.8,
            maxWidth: 680,
          }}
        >
          Klub Capital reduces friction by making opportunities more structured,
          selective, and relevant.
        </p>
      </Reveal>
    </div>
  </section>
);

export default Problem;
