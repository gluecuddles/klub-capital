import Reveal from "./Reveal";

const FinalCTA = () => (
  <section
    style={{
      padding: "120px 40px",
      textAlign: "center",
      background: "#1C1C1C",
    }}
  >
    <div style={{ maxWidth: 680, margin: "0 auto" }}>
      <Reveal>
        <h2
          className="serif"
          style={{
            fontSize: "clamp(40px, 6vw, 76px)",
            fontWeight: 300,
            color: "#F7F6F3",
            marginBottom: 28,
            lineHeight: 1.1,
            fontStyle: "italic",
          }}
        >
          Enter the right room.
        </h2>

        <p
          style={{
            fontSize: 17,
            fontWeight: 300,
            color: "rgba(247,246,243,0.55)",
            lineHeight: 1.8,
            marginBottom: 52,
          }}
        >
          Whether you are allocating capital or seeking it, Klub Capital is
          designed to make the first interaction more intelligent.
        </p>

        <div
          style={{
            display: "flex",
            gap: 16,
            justifyContent: "center",
            flexWrap: "wrap",
            marginBottom: 40,
          }}
        >
          <button
            style={{
              display: "inline-block",
              padding: "13px 32px",
              border: "1px solid #C7A96B",
              background: "#C7A96B",
              color: "#fff",
              fontFamily: "'DM Sans', sans-serif",
              fontSize: 13,
              fontWeight: 400,
              letterSpacing: "0.08em",
              cursor: "pointer",
              textTransform: "uppercase",
              transition: "all 0.2s",
            }}
            onMouseEnter={(e) => {
              e.target.style.background = "#b8975a";
              e.target.style.borderColor = "#b8975a";
            }}
            onMouseLeave={(e) => {
              e.target.style.background = "#C7A96B";
              e.target.style.borderColor = "#C7A96B";
            }}
          >
            Apply as Investor
          </button>
          <button
            style={{
              display: "inline-block",
              padding: "13px 32px",
              border: "1px solid rgba(247,246,243,0.3)",
              background: "transparent",
              color: "#F7F6F3",
              fontFamily: "'DM Sans', sans-serif",
              fontSize: 13,
              fontWeight: 400,
              letterSpacing: "0.08em",
              cursor: "pointer",
              textTransform: "uppercase",
              transition: "all 0.2s",
            }}
            onMouseEnter={(e) => {
              e.target.style.borderColor = "rgba(247,246,243,0.6)";
            }}
            onMouseLeave={(e) => {
              e.target.style.borderColor = "rgba(247,246,243,0.3)";
            }}
          >
            Submit a Business
          </button>
        </div>

        <p
          style={{
            fontSize: 11,
            letterSpacing: "0.16em",
            textTransform: "uppercase",
            color: "rgba(247,246,243,0.3)",
          }}
        >
          Private access. Selective review. Quality over volume.
        </p>
      </Reveal>
    </div>
  </section>
);

export default FinalCTA;
