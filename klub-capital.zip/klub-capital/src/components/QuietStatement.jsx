import Reveal from "./Reveal";

const QuietStatement = () => (
  <section
    style={{ padding: "80px 40px", maxWidth: 720, margin: "0 auto", textAlign: "center" }}
  >
    <hr className="thin-rule" style={{ marginBottom: 80 }} />
    <Reveal>
      <p
        className="serif"
        style={{
          fontSize: "clamp(26px, 3.5vw, 38px)",
          fontWeight: 300,
          lineHeight: 1.5,
          color: "#1C1C1C",
          marginBottom: 40,
          fontStyle: "italic",
        }}
      >
        Private markets were never designed for noise.
      </p>
      <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
        {[
          "Investors spend time filtering irrelevant opportunities.",
          "Businesses struggle to reach the right capital.",
          "Klub Capital exists to bring structure and clarity to that interaction.",
        ].map((line, i) => (
          <p
            key={i}
            style={{
              fontSize: 16,
              fontWeight: 300,
              color: i === 2 ? "#1C1C1C" : "#6B6B6B",
              lineHeight: 1.7,
            }}
          >
            {line}
          </p>
        ))}
      </div>
    </Reveal>
  </section>
);

export default QuietStatement;
