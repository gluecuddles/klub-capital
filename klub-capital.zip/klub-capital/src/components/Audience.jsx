import Reveal from "./Reveal";

const cols = [
  {
    label: "For Investors",
    desc: "Discover curated private opportunities without unnecessary noise.",
    items: [
      "Sector-aligned opportunities",
      "Relevant deal flow",
      "Structured visibility",
      "Selective access",
    ],
    cta: "Join as Investor",
    dark: false,
  },
  {
    label: "For Businesses",
    desc: "Access serious capital once your business is ready to be seen.",
    items: [
      "Readiness-focused intake",
      "Selective review",
      "Capital matching",
      "Stronger investor positioning",
    ],
    cta: "Apply as a Business",
    dark: true,
  },
];

const Audience = () => (
  <section style={{ background: "#EFEDE7", padding: "100px 40px" }}>
    <div
      style={{
        maxWidth: 1080,
        margin: "0 auto",
        display: "grid",
        gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
        gap: 2,
      }}
    >
      {cols.map((col, ci) => (
        <Reveal key={ci} delay={ci * 0.15}>
          <div
            style={{
              padding: "60px 48px",
              background: col.dark ? "#1C1C1C" : "#F7F6F3",
              minHeight: 480,
              display: "flex",
              flexDirection: "column",
            }}
          >
            <p
              style={{
                fontSize: 11,
                letterSpacing: "0.2em",
                textTransform: "uppercase",
                color: "#C7A96B",
                marginBottom: 24,
              }}
            >
              {col.label}
            </p>
            <p
              style={{
                fontSize: 17,
                fontWeight: 300,
                color: col.dark ? "#F7F6F3" : "#1C1C1C",
                lineHeight: 1.7,
                marginBottom: 40,
              }}
            >
              {col.desc}
            </p>
            <div
              style={{
                flex: 1,
                display: "flex",
                flexDirection: "column",
                gap: 0,
                marginBottom: 48,
              }}
            >
              {col.items.map((item, i) => (
                <div
                  key={i}
                  style={{
                    padding: "14px 0",
                    borderTop: col.dark
                      ? "1px solid rgba(255,255,255,0.1)"
                      : "1px solid #E4E4E4",
                  }}
                >
                  <p
                    style={{
                      fontSize: 14,
                      fontWeight: 300,
                      color: col.dark
                        ? "rgba(247,246,243,0.7)"
                        : "#6B6B6B",
                    }}
                  >
                    {item}
                  </p>
                </div>
              ))}
              <div
                style={{
                  borderTop: col.dark
                    ? "1px solid rgba(255,255,255,0.1)"
                    : "1px solid #E4E4E4",
                }}
              />
            </div>
            <a
              className="text-link"
              href="#"
              style={{
                color: col.dark ? "#C7A96B" : "#1C1C1C",
                borderBottomColor: "#C7A96B",
              }}
            >
              {col.cta}
            </a>
          </div>
        </Reveal>
      ))}
    </div>
  </section>
);

export default Audience;
