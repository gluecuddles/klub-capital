import Reveal from "./Reveal";

const steps = [
  {
    n: "1",
    title: "Apply privately",
    body: "Submit your application through our confidential intake process.",
  },
  {
    n: "2",
    title: "Get reviewed and profiled",
    body: "Our team reviews each application to assess fit and readiness.",
  },
  {
    n: "3",
    title: "Receive curated visibility or matching",
    body: "Qualified participants are surfaced to relevant counterparts.",
  },
  {
    n: "4",
    title: "Move into qualified conversations",
    body: "Introductions are made when alignment is confirmed on both sides.",
  },
];

const HowItWorks = () => (
  <section style={{ padding: "100px 40px" }}>
    <div style={{ maxWidth: 1080, margin: "0 auto" }}>
      <Reveal>
        <p
          style={{
            fontSize: 11,
            letterSpacing: "0.2em",
            textTransform: "uppercase",
            color: "#C7A96B",
            marginBottom: 24,
          }}
        >
          Process
        </p>
        <h2
          className="serif"
          style={{
            fontSize: "clamp(30px, 4vw, 50px)",
            fontWeight: 300,
            marginBottom: 80,
            lineHeight: 1.2,
          }}
        >
          How Klub Capital works
        </h2>
      </Reveal>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
          gap: 40,
        }}
      >
        {steps.map((s, i) => (
          <Reveal key={i} delay={i * 0.1}>
            <div style={{ paddingRight: 24 }}>
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 12,
                  marginBottom: 20,
                }}
              >
                <span
                  style={{
                    width: 28,
                    height: 28,
                    border: "1px solid #E4E4E4",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: 11,
                    color: "#C7A96B",
                    flexShrink: 0,
                  }}
                >
                  {s.n}
                </span>
                <div
                  style={{
                    flex: 1,
                    height: "1px",
                    background:
                      i < steps.length - 1 ? "#E4E4E4" : "transparent",
                  }}
                />
              </div>
              <p
                className="serif"
                style={{
                  fontSize: 19,
                  fontWeight: 400,
                  color: "#1C1C1C",
                  marginBottom: 12,
                  lineHeight: 1.3,
                }}
              >
                {s.title}
              </p>
              <p
                style={{
                  fontSize: 14,
                  fontWeight: 300,
                  color: "#6B6B6B",
                  lineHeight: 1.7,
                }}
              >
                {s.body}
              </p>
            </div>
          </Reveal>
        ))}
      </div>
    </div>
  </section>
);

export default HowItWorks;
