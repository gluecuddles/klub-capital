import Reveal from "./Reveal";

const items = [
  {
    title: "Investor-first design",
    body: "Built around relevance, not volume.",
  },
  {
    title: "Selective access",
    body: "The network stays curated to preserve quality.",
  },
  {
    title: "Capital readiness layer",
    body: "Businesses are prepared before they are presented.",
  },
  {
    title: "Discreet by design",
    body: "Private opportunities require trust, structure, and control.",
  },
];

const Differentiation = () => (
  <section style={{ background: "#EFEDE7", padding: "100px 40px" }}>
    <div style={{ maxWidth: 1080, margin: "0 auto" }}>
      <Reveal>
        <h2
          className="serif"
          style={{
            fontSize: "clamp(30px, 4vw, 50px)",
            fontWeight: 300,
            marginBottom: 72,
            lineHeight: 1.2,
          }}
        >
          Not another deal board.
        </h2>
      </Reveal>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
          gap: 2,
        }}
      >
        {items.map((item, i) => (
          <Reveal key={i} delay={i * 0.08}>
            <div
              style={{
                background: "#F7F6F3",
                padding: "44px 40px",
                minHeight: 200,
              }}
            >
              <p
                className="serif"
                style={{
                  fontSize: 20,
                  fontWeight: 400,
                  color: "#1C1C1C",
                  marginBottom: 14,
                  lineHeight: 1.3,
                }}
              >
                {item.title}
              </p>
              <p
                style={{
                  fontSize: 14,
                  fontWeight: 300,
                  color: "#6B6B6B",
                  lineHeight: 1.7,
                }}
              >
                {item.body}
              </p>
            </div>
          </Reveal>
        ))}
      </div>
    </div>
  </section>
);

export default Differentiation;
