import Reveal from "./Reveal";

const blocks = [
  {
    label: "01",
    title: "Capital Readiness",
    body: "Businesses are prepared with greater clarity before they are presented to investors.",
  },
  {
    label: "02",
    title: "Curated Deal Flow",
    body: "Only selected opportunities move forward. Quality matters more than volume.",
  },
  {
    label: "03",
    title: "Relevant Introductions",
    body: "Investors see opportunities aligned with sector, size, stage, and interest.",
  },
];

const Solution = () => (
  <section style={{ padding: "100px 40px" }}>
    <div style={{ maxWidth: 1080, margin: "0 auto" }}>
      <Reveal>
        <h2
          className="serif"
          style={{
            fontSize: "clamp(28px, 3.5vw, 46px)",
            fontWeight: 300,
            marginBottom: 72,
            lineHeight: 1.3,
            maxWidth: 600,
          }}
        >
          A more intelligent way to connect capital and opportunity.
        </h2>
      </Reveal>

      {blocks.map((b, i) => (
        <Reveal key={i} delay={i * 0.1}>
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "60px 1fr 2fr",
              gap: 40,
              padding: "40px 0",
              borderTop: "1px solid #E4E4E4",
              alignItems: "start",
            }}
          >
            <span
              style={{
                fontSize: 11,
                color: "#C7A96B",
                letterSpacing: "0.1em",
                paddingTop: 2,
              }}
            >
              {b.label}
            </span>
            <p
              className="serif"
              style={{
                fontSize: 22,
                fontWeight: 400,
                color: "#1C1C1C",
                lineHeight: 1.3,
              }}
            >
              {b.title}
            </p>
            <p
              style={{
                fontSize: 15,
                fontWeight: 300,
                color: "#6B6B6B",
                lineHeight: 1.75,
              }}
            >
              {b.body}
            </p>
          </div>
        </Reveal>
      ))}

      <div style={{ borderTop: "1px solid #E4E4E4" }} />
    </div>

    {/* Responsive grid fix for small screens */}
    <style>{`
      @media (max-width: 640px) {
        .solution-row {
          grid-template-columns: 40px 1fr !important;
        }
        .solution-row .solution-body {
          grid-column: 1 / -1;
        }
      }
    `}</style>
  </section>
);

export default Solution;
