import Reveal from "./Reveal";

const tags = ["Invite-only", "Curated intake", "Selective review", "Private by design"];

const TrustAccess = () => (
  <section style={{ padding: "100px 40px", background: "#F7F6F3" }}>
    <div style={{ maxWidth: 760, margin: "0 auto", textAlign: "center" }}>
      <Reveal>
        <div
          style={{
            display: "flex",
            gap: 8,
            justifyContent: "center",
            flexWrap: "wrap",
            marginBottom: 56,
          }}
        >
          {tags.map((tag, i) => (
            <span
              key={i}
              style={{
                fontSize: 11,
                letterSpacing: "0.14em",
                textTransform: "uppercase",
                color: "#6B6B6B",
                border: "1px solid #E4E4E4",
                padding: "6px 14px",
              }}
            >
              {tag}
            </span>
          ))}
        </div>

        <p
          style={{
            fontSize: 11,
            letterSpacing: "0.2em",
            textTransform: "uppercase",
            color: "#C7A96B",
            marginBottom: 24,
          }}
        >
          Access
        </p>

        <h2
          className="serif"
          style={{
            fontSize: "clamp(32px, 4vw, 54px)",
            fontWeight: 300,
            marginBottom: 32,
            lineHeight: 1.2,
          }}
        >
          Access is curated.
        </h2>

        <p
          style={{
            fontSize: 17,
            fontWeight: 300,
            color: "#6B6B6B",
            lineHeight: 1.8,
            marginBottom: 24,
          }}
        >
          Klub Capital is not an open marketplace. Participation is reviewed to
          maintain quality across investors, businesses, and opportunities.
        </p>

        <p
          style={{
            fontSize: 13,
            letterSpacing: "0.1em",
            textTransform: "uppercase",
            color: "#ABABAB",
          }}
        >
          Designed for serious participants only.
        </p>
      </Reveal>
    </div>
  </section>
);

export default TrustAccess;
