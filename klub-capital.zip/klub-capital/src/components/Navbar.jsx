import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const links = ["About", "Investors", "Businesses", "How It Works", "Apply"];

  return (
    <motion.nav
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        zIndex: 100,
        backgroundColor: scrolled ? "rgba(247,246,243,0.96)" : "transparent",
        borderBottom: scrolled ? "1px solid #E4E4E4" : "1px solid transparent",
        backdropFilter: scrolled ? "blur(12px)" : "none",
        WebkitBackdropFilter: scrolled ? "blur(12px)" : "none",
        transition: "all 0.4s ease",
        padding: "0 40px",
      }}
    >
      <div
        style={{
          maxWidth: 1200,
          margin: "0 auto",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          height: 64,
        }}
      >
        {/* Logo */}
        <div
          className="serif"
          style={{
            fontSize: 18,
            fontWeight: 400,
            letterSpacing: "0.12em",
            textTransform: "uppercase",
          }}
        >
          Klub Capital
        </div>

        {/* Desktop links */}
        <div
          className="mobile-hidden"
          style={{ display: "flex", gap: 36, alignItems: "center" }}
        >
          {links.map((l) => (
            <a
              key={l}
              href="#"
              style={{
                fontSize: 12,
                letterSpacing: "0.08em",
                textTransform: "uppercase",
                color: "#6B6B6B",
                textDecoration: "none",
                transition: "color 0.2s",
              }}
              onMouseEnter={(e) => (e.target.style.color = "#1C1C1C")}
              onMouseLeave={(e) => (e.target.style.color = "#6B6B6B")}
            >
              {l}
            </a>
          ))}
        </div>

        {/* Mobile hamburger */}
        <button
          onClick={() => setMenuOpen(!menuOpen)}
          style={{
            display: "none",
            background: "none",
            border: "none",
            cursor: "pointer",
            padding: 4,
            flexDirection: "column",
            gap: 5,
          }}
          id="hamburger"
          aria-label="Toggle menu"
        >
          <div style={{ width: 22, height: 1, background: "#1C1C1C" }} />
          <div style={{ width: 14, height: 1, background: "#1C1C1C" }} />
        </button>
      </div>

      {/* Mobile menu */}
      <AnimatePresence>
        {menuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
            style={{
              background: "#F7F6F3",
              borderTop: "1px solid #E4E4E4",
              padding: "24px 40px 32px",
            }}
          >
            {links.map((l) => (
              <a
                key={l}
                href="#"
                onClick={() => setMenuOpen(false)}
                style={{
                  display: "block",
                  fontSize: 13,
                  letterSpacing: "0.08em",
                  textTransform: "uppercase",
                  color: "#6B6B6B",
                  textDecoration: "none",
                  padding: "12px 0",
                  borderBottom: "1px solid #F0EFE9",
                }}
              >
                {l}
              </a>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      <style>{`
        @media (max-width: 768px) {
          #hamburger { display: flex !important; }
        }
      `}</style>
    </motion.nav>
  );
};

export default Navbar;
